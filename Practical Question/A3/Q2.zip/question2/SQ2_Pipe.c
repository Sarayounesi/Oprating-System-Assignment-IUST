#include <sys/ipc.h>
#include <stdio.h>

#include <stdlib.h>
#include <unistd.h>

#include <wait.h>

#include <string.h>
#include <sys/stat.h>

#include <sys/shm.h>
#include <pthread.h>

#include <string.h>
#include <time.h>

#define IN_LEN 5
#define PIPE_NO 1
#define CHAR_SIZE 150

int main()
{

    char  INuser [IN_LEN][CHAR_SIZE];
    char  Outu   [IN_LEN][CHAR_SIZE];
    int   PIPES       [PIPE_NO][2];
    int pid;

    FILE *file = fopen("Logs.txt", "w");

    if (file == NULL)
    {
        perror("| Can't Open File |\n");
    }

    for (size_t i = 0; i < PIPE_NO; i++)
    {
        pipe(  PIPES[i]);
    }


    pid = fork();

    if (pid > 0)
    {

        pid_t newPID = fork();
        if (newPID > 0)
        {
            for (int i = 0; i < 3; i++)
            {
                char temp[CHAR_SIZE];
                sprintf(temp, "IDWorker[%d] : LOG[%d]", i, rand() % 101);

                strcpy(INuser[i], temp);

                printf("%s \n\n", INuser[i]);
            }
            for (int i = 0; i < 3; i++)
            {
                write(  PIPES[0][1], &INuser[i], sizeof(char) * CHAR_SIZE);
            }
        }
        else if (newPID == 0)
        {
           
            for (int i = 3; i < 5; i++)
            {
                char temp[CHAR_SIZE];

                sprintf(temp, "IDWorker[%d] : LOG[%d]", i, rand() % 101);

                strcpy(INuser[i], temp);

                printf("%s \n\n", INuser[i]);
            }

            for (int i = 3; i < 5; i++)
            {
                write(  PIPES[0][1], &INuser[i], sizeof(char) * CHAR_SIZE);
            }
        }
        else
        {
            perror(" |We Have NO Child| ");
        }
    }
    else if (pid == 0)
    {
       
        for (size_t i = 0; i < IN_LEN; i++)
        {
            read(  PIPES[0][0], 
                   &outputs[i], 
                   sizeof(char) * CHAR_SIZE);

            printf("GET: %s\n\n", outputs[i]);

            fprintf(file, "%s\n", outputs[i]);
        }
    }
    else
    {
        perror("|We Have NO Child|");
    }
}
