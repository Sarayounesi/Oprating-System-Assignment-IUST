#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/ipc.h>
#include <fcntl.h>

#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <sys/mman.h>

#include <errno.h>
#include <sys/shm.h>
#include <sys/time.h>
#include <time.h>

#pragma once
#define IN_LEN 10

#define FINISH -999

#define PROC_NO 4

#define SIZE 1024

#define NAME "my_shr_mem"
#define SEM_NAME "my_sem1"

//SIGNIFICANT FOR ARRAY

#define LENGTH 7


void merge(int arr[], int INDEXSTART, int INDEXMID, int INDEXEND)
{
	int FINALINDEX;
	int SENDINDEX;
	int ININDEX;

	int LEFTARRAY[INDEXMID - INDEXSTART + 1];
	int RIGHTARRAY[INDEXEND - INDEXMID];

	int LEFT_SIDE ;
	LEFT_SIDE= INDEXMID - INDEXSTART + 1;
	int RIGHT_SIDE ;
	RIGHT_SIDE= INDEXEND - INDEXMID;

	for (FINALINDEX = 0; FINALINDEX < LEFT_SIDE; FINALINDEX++)
	{
		LEFTARRAY[FINALINDEX] = arr[INDEXSTART + FINALINDEX];
	}
	for (SENDINDEX = 0; SENDINDEX < RIGHT_SIDE; SENDINDEX++)
	{
		RIGHTARRAY[SENDINDEX] = arr[INDEXMID + 1 + SENDINDEX];
	}

	FINALINDEX = 0;
	SENDINDEX = 0;
	ININDEX = INDEXSTART;

	while (FINALINDEX < LEFT_SIDE && SENDINDEX < RIGHT_SIDE)
	{
		if (LEFTARRAY[FINALINDEX] <= RIGHTARRAY[SENDINDEX])
		{
			arr[ININDEX] = LEFTARRAY[FINALINDEX];
			FINALINDEX++;
		}
		else
		{
			arr[ININDEX] = RIGHTARRAY[SENDINDEX];
			SENDINDEX++;
		}
		ININDEX++;
	}

	while (FINALINDEX < LEFT_SIDE)
	{
		arr[ININDEX] = LEFTARRAY[FINALINDEX];
		FINALINDEX++;
		ININDEX++;
	}
	while (SENDINDEX < RIGHT_SIDE)
	{
		arr[ININDEX] = RIGHTARRAY[SENDINDEX];
		SENDINDEX++;
		ININDEX++;
	}
}

void MergeSort(int arr[], int INDEXSTART, int INDEXEND)
{
	int state;
	pid_t Left_Child = 0;
	pid_t Right_Child = 0;

	int INDEXMID ;
	INDEXMID = (INDEXSTART + INDEXSTART) / 2;
	if (INDEXEND - INDEXSTART <= 0)
	{
		return;
	}
	else
	{
		Left_Child = fork();
		if (Left_Child == 0)
		{
			MergeSort(arr, INDEXSTART, INDEXMID);
			exit(0);
		}
		else if (Left_Child < 0)
		{
			perror("bache naghes shod\n");
			exit(1);
		}
		else if (Left_Child > 0)
		{
			Right_Child = fork();
			if (Right_Child == 0)
			{
				MergeSort(arr, INDEXMID + 1, INDEXEND);
				exit(0);
			}
			else if (Right_Child < 0)
			{
				perror("bache naghes shod\n");
				exit(1);
			}
		}
		pid_t Temp_Pid_Left;
		Temp_Pid_Left= waitpid(Left_Child, &state, WUNTRACED);
		pid_t Temp_Pid_Right ;
		Temp_Pid_Right waitpid(Right_Child, &state, WUNTRACED);

	}
	merge(arr, INDEXSTART, INDEXMID, INDEXEND);
}

int main(int argc, char *argv[])
{
	srand(time(NULL));
	int shm_fd;
	int *arr;
	shm_fd = shm_open(NAME, O_CREAT | O_RDWR, 0666);
	if (shm_fd < 0)
	{
		perror("Failed to open shared mem");
		return 1;
	}
	ftruncate(shm_fd, SIZE);
	arr = (int *)mmap(0, SIZE, PROT_WRITE, MAP_SHARED, shm_fd, 0);

	for (int i = 0; i < LENGTH; i++)
	{
		arr[i] = rand() % 101;
	}
	for (int i = 0; i < LENGTH; i++)
		printf("%d ", arr[i]);

//FIRST PRINT
	printf("\n");

	MergeSort(arr, 0, LENGTH - 1);

	for (int i = 0; i < LENGTH; i++)
		printf("%d ", arr[i]);

//SECOND PRINT
	printf("\n");

	munmap(arr, SIZE);

	close(shm_fd);

	return 0;
}